# Where's the Weef?
## A Text Adventure
You and your friends have just received your meals at your quadrant's Amazing Taste franchise, the only consistently stocked food source around.
Before you each sits a Weef™ patty hardly bigger than the smaller cockroaches that rule the corners of the building.
That's the last straw. With your 1337 DIY cyberdeck, you're going to fix things around here.

Run main.py to play. Requires python3.